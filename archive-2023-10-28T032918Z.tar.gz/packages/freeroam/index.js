// Init events.
require('./events.js');
// Init commands.
require('./commands.js');
